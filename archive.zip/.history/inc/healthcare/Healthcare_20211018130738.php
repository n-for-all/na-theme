<?php

namespace NaTheme\Inc\Healthcare;

class Healthcare
{
    public function __construct()
    {
        $this->departments = new Department();
        $this->doctors = new Doctor();
    }
}
?>