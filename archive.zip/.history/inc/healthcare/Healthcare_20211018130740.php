<?php

namespace NaTheme\Inc\Healthcare;

class Healthcare
{
    public function __construct()
    {
        die();
        $this->departments = new Department();
        $this->doctors = new Doctor();
    }
}
?>