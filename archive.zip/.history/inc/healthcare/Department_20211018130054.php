<?php

namespace NaTheme\Inc\Healthcare;

class Department
{
    public function __construct()
    {
        add_action('init', array(&$this, 'init'));
        add_action('wp_enqueue_scripts', array(&$this, 'scripts'));
        add_shortcode('departments', array(&$this, 'render'));

        add_filter('manage_department_posts_columns', array(&$this, 'add_img_column'));
        add_filter('manage_department_posts_custom_column', array(&$this, 'manage_img_column'), 10, 2);

        global $SLIDER_METABOXES;
        $SLIDER_METABOXES = new Metabox(array('department'), 'Departments');

        new PostImage("department-icon", "Icon", "icon", "departments", 2);
    }
    public function init()
    {
        $labels = array(
            'name'               => _x('Departments', 'post type general name', NA_THEME_TEXT_DOMAIN),
            'singular_name'      => _x('Department', 'post type singular name', NA_THEME_TEXT_DOMAIN),
            'menu_name'          => _x('Departmentr', 'admin menu', NA_THEME_TEXT_DOMAIN),
            'name_admin_bar'     => _x('Department', 'add new on admin bar', NA_THEME_TEXT_DOMAIN),
            'add_new'            => _x('Add New', 'book', NA_THEME_TEXT_DOMAIN),
            'add_new_item'       => __('Add New Department', NA_THEME_TEXT_DOMAIN),
            'new_item'           => __('New Department', NA_THEME_TEXT_DOMAIN),
            'edit_item'          => __('Edit Department', NA_THEME_TEXT_DOMAIN),
            'view_item'          => __('View Department', NA_THEME_TEXT_DOMAIN),
            'all_items'          => __('All Departments', NA_THEME_TEXT_DOMAIN),
            'search_items'       => __('Search Departments', NA_THEME_TEXT_DOMAIN),
            'parent_item_colon'  => __('Parent Departments:', NA_THEME_TEXT_DOMAIN),
            'not_found'          => __('No departments found.', NA_THEME_TEXT_DOMAIN),
            'not_found_in_trash' => __('No departments found in Trash.', NA_THEME_TEXT_DOMAIN)
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'department'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array('title', 'editor', 'thumbnail', 'page-attributes')
        );

        register_post_type('department', $args);
    }
    public function add_img_column($columns)
    {
        $columns['img'] = 'Image';
        return $columns;
    }
    public function manage_img_column($column_name, $post_id)
    {
        if ($column_name == 'img') {
            echo get_the_post_thumbnail($post_id, 'thumbnail');
        }
        return $column_name;
    }
    public function scripts()
    {
        wp_enqueue_script('na-healthcare-departments-hammer', get_template_directory_uri() . '/inc/healthcare/js/hammer.min.js', array(), '1.0.0', true);
        wp_enqueue_script('na-healthcare-departments', get_template_directory_uri() . '/inc/healthcare/js/departments.js', array('na-departments-hammer'), '1.0.0', true);
        wp_enqueue_style('na-healthcare-departments', get_template_directory_uri() . '/inc/healthcare/css/departments.css', array(), '1.0');
    }
    public function render($atts)
    {
        $atts = shortcode_atts(array(
            'id' => 0,
            'category' => 0,
            'container' => 'container',
            'height' => '100%',
            'type' => '',
            'max' => false,
            'vertical' => 0,
            'autoplay' => 0,
            'thumbnails' => 0,
            'bullets' => 0,
            'min-width' => 0,
            'columns' => 1
        ), $atts);
        if ($atts['id'] != 0) {
            $atts['category'] = $atts['id'];
        }
        $departments = get_posts(
            array(
                'post_type' => 'department',
                'posts_per_page' => -1,
                'orderby' => 'menu_order',
                'order' => 'ASC',
                'suppress_filters' => false,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'departments',
                        'field' => is_numeric($atts['category']) ? 'term_id' : 'slug',
                        'terms' => $atts['category']
                    )
                )
            )
        );
        $settings = array();
        $_departments = array();
        if (count($departments) > 0) {
            $settings = array(
                'autoplay' => $atts['autoplay'],
                'container' => $atts['container'],
                'bullets' => $atts['bullets'],
                'thumbnails' => $atts['thumbnails'],
                'columns' => $atts['columns'],
                'vertical' => $atts['vertical'],
                'minWidth' => $atts['min-width'] > 0 ? $atts['min-width'] : 200,
                'type' => $atts['type'],
                'height' => $atts['height']
            );
            if ($atts['type'] == 'mosaic') {
                for ($i = 0; $i < count($departments); $i = $i + 2) :
                    $department1 = $departments[$i];
                    $department2 = $departments[$i + 1];
                    $image1 = '';
                    $image2 = '';
                    if (has_post_thumbnail($department1->ID)) {
                        $image1 = wp_get_attachment_image_src(get_post_thumbnail_id($department1->ID), "full")[0];
                    }
                    if (has_post_thumbnail($department2->ID)) {
                        $image2 = wp_get_attachment_image_src(get_post_thumbnail_id($department2->ID), "full")[0];
                    }
                    $_departments[] = array('content' => '<div class="na-department-inner na-departments-inner1" style="background:url(' . $image1 . ') no-repeat top center / cover;width:100%">
    						<div class="na-department-text">
    							' . apply_filters('the_content', $department1->post_content) . '
    						</div>
    					</div>
    					<div class="na-department-inner na-departments-inner2" style="background:url(' . $image2 . ') no-repeat top center / cover;width:100%">
    						<div class="na-department-text">
    						     ' . apply_filters('the_content', $department2->post_content) . '
    						</div>
    					</div>', 'post' => [$department1, $department2]);
                endfor;
            } else {
                foreach ($departments as $department) :
                    $image = '';
                    if (has_post_thumbnail($department->ID)) {
                        $image = wp_get_attachment_image_src(get_post_thumbnail_id($department->ID), "full")[0];
                    }

                    $content = sprintf('<div class="na-department-text">%s</div>', apply_filters('the_content', $department->post_content));
                    $_departments[] = array('content' => sprintf('<div style="background-image:url(%s)" class="na-department-inner">
                        %s
    				</div>', $image, $settings['container'] == 'container' ? sprintf('<div class="container"><div class="row"><div class="col-md-12">%s</div></div></div>', $content) : $content), 'post' => $department);
                    if ($atts['max'] && $atts['max'] < count($_departments)) {
                        break;
                    }
                endforeach;
            }
        }
        return $this->addDepartmentr($_departments, $settings);
    }
    public function addDepartmentr($departments, $settings)
    {
        if (count($departments) > 0) {
            $id = uniqid('departments_');
            ob_start();
            if (isset($settings['thumbnails']) && $settings['thumbnails']) {
                $settings['sync'] = $id . '_thumbnails';
            }
            include('template/departments.tpl.php');

            return ob_get_clean();
        }
    }
}
class Metabox extends \NaTheme\Inc\Metaboxes\Metabox
{
    public function show_metabox($post)
    {
?>
        <table class="form-table">
            <tbody>
                <tr class="form-field form-required term-name-wrap">
                    <th scope="row"><label for="name">Choose images</label></th>
                    <td><?php $this->_metabox_image($post->ID, 'icon', 'department'); ?>
                        <p class="description">Choose your department icon, those images will appear in the departments shortcode of your website.</p>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php

    }
}


class PostImage extends \NaTheme\Inc\Metaboxes\Admin\PostColumn
{
    public function show_content($column, $post_id)
    {
        global $SLIDER_METABOXES;
        $images = $SLIDER_METABOXES->_metabox_image_value($post_id, 'icon', 'department');
        //print_r();
        foreach ($images as $image) {
        ?>
            <img src="<?php echo $image[0]; ?>" style="height:50px" />
<?php

        }
    }
}

?>