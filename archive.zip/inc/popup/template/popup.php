<div class="entry-content">
    <# if(data.image) {#>
        <img class="featured" src="{{data.image}}"/>
    <# } #>
    <h2>
        {{{data.title}}}
    </h2>
    {{{ data.content }}}
</div>
